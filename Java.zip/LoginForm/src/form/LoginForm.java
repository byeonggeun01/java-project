package form;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.SwingUtilities;

import dao.UserDAO;
import dto.UserDTO;
import view.View;

public class LoginForm extends JFrame {
    private JTextField idField;
    private JPasswordField pwField;
    private JButton loginButton;
    private JButton registerButton;

    public LoginForm() {
        setTitle("Login Form");
        setSize(300, 200);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        JPanel panel = new JPanel();
        add(panel);
        placeComponents(panel);

        setVisible(true);
    }

    private void placeComponents(JPanel panel) {
        panel.setLayout(null);

        JLabel userLabel = new JLabel("User ID:");
        userLabel.setBounds(10, 10, 80, 25);
        panel.add(userLabel);

        idField = new JTextField(20);
        idField.setBounds(100, 10, 160, 25);
        panel.add(idField);

        JLabel passwordLabel = new JLabel("Password:");
        passwordLabel.setBounds(10, 40, 80, 25);
        panel.add(passwordLabel);

        pwField = new JPasswordField(20);
        pwField.setBounds(100, 40, 160, 25);
        panel.add(pwField);

        loginButton = new JButton("Login");
        loginButton.setBounds(10, 80, 120, 25);
        panel.add(loginButton);

        registerButton = new JButton("회원가입");
        registerButton.setBounds(140, 80, 120, 25);
        panel.add(registerButton);

        loginButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String id = idField.getText();
                String pw = new String(pwField.getPassword());

                if (id.equals("admin") && pw.equals("1234")) {
                    dispose();
                    SwingUtilities.invokeLater(() -> new View());
                } else {
                    UserDAO dao = new UserDAO();
                    UserDTO dto = dao.selectOne(id, pw);
                    if (dto != null) {
                        JOptionPane.showMessageDialog(null,
                            "로그인 성공\nID: " + dto.getId() + "\n이름: " + dto.getName());
                    } else {
                        JOptionPane.showMessageDialog(null, "로그인 실패: ID 또는 비밀번호 오류");
                    }
                }
            }
        });

        registerButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                new JoinForm();
            }
        });
    }

    public static void main(String[] args) {
        new LoginForm();
    }
}


