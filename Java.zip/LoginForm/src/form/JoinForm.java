
package form;

import dto.UserDTO;
import dao.UserDAO;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class JoinForm extends JFrame {
    private JTextField idField, nameField;
    private JPasswordField pwField;
    private JButton registerButton;

    public JoinForm() {
        setTitle("회원가입");
        setSize(300, 250);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);

        JPanel panel = new JPanel();
        panel.setLayout(null);
        add(panel);

        JLabel nameLabel = new JLabel("이름:");
        nameLabel.setBounds(10, 10, 80, 25);
        panel.add(nameLabel);

        nameField = new JTextField();
        nameField.setBounds(100, 10, 160, 25);
        panel.add(nameField);

        JLabel idLabel = new JLabel("ID:");
        idLabel.setBounds(10, 50, 80, 25);
        panel.add(idLabel);

        idField = new JTextField();
        idField.setBounds(100, 50, 160, 25);
        panel.add(idField);

        JLabel pwLabel = new JLabel("비밀번호:");
        pwLabel.setBounds(10, 90, 80, 25);
        panel.add(pwLabel);

        pwField = new JPasswordField();
        pwField.setBounds(100, 90, 160, 25);
        panel.add(pwField);

        registerButton = new JButton("가입");
        registerButton.setBounds(100, 130, 80, 30);
        panel.add(registerButton);

        registerButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String name = nameField.getText();
                String id = idField.getText();
                String pw = new String(pwField.getPassword());

                UserDTO dto = new UserDTO(id, pw, name);
                UserDAO dao = new UserDAO();
                int result = dao.insert(dto);

                if (result > 0) {
                    JOptionPane.showMessageDialog(null, "회원가입 성공");
                    dispose();
                } else {
                    JOptionPane.showMessageDialog(null, "회원가입 실패: 중복 ID 또는 DB 오류");
                }
            }
        });

        setVisible(true);
    }
}
